# initializing env setting

`npm init`

`npm install sqlite sqlite3`

`npm install express`

`npm install nodemon`

# execution

`node database.js`
